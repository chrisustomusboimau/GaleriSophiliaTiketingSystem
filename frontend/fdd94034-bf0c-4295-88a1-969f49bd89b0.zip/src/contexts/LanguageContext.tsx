import React, { useState, createContext, useContext } from 'react';
type Language = 'id' | 'en' | 'zh';
interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  translations: {
    [key: string]: { [key in Language]: string };
  };
}
const defaultTranslations = {
  welcomeTitle: {
    id: 'Selamat Datang di Museum',
    en: 'Welcome to the Museum',
    zh: '欢迎来到博物馆'
  },
  welcomeDescription: {
    id: 'Silakan pilih bahasa Anda untuk melanjutkan',
    en: 'Please select your language to continue',
    zh: '请选择您的语言以继续'
  },
  continueButton: {
    id: 'Lanjutkan',
    en: 'Continue',
    zh: '继续'
  },
  ticketingTitle: {
    id: 'Pembelian Tiket Museum',
    en: 'Museum Ticketing',
    zh: '博物馆售票'
  },
  visitorCount: {
    id: 'Jumlah Pengunjung',
    en: 'Visitor Count',
    zh: '访客数量'
  },
  visitorDescription: {
    id: 'Masukkan jumlah pengunjung berdasarkan usia',
    en: 'Enter the number of visitors by age',
    zh: '按年龄输入访客数量'
  },
  childLabel: {
    id: 'Anak (Di bawah 8 tahun)',
    en: 'Child (Under 8 years)',
    zh: '儿童（8岁以下）'
  },
  teenLabel: {
    id: 'Remaja (Di bawah 22 tahun)',
    en: 'Teen (Under 22 years)',
    zh: '青少年（22岁以下）'
  },
  adultLabel: {
    id: 'Dewasa (22 tahun ke atas)',
    en: 'Adult (22 years and above)',
    zh: '成人（22岁及以上）'
  },
  totalVisitors: {
    id: 'Total Pengunjung:',
    en: 'Total Visitors:',
    zh: '访客总数：'
  },
  totalPrice: {
    id: 'Total Harga:',
    en: 'Total Price:',
    zh: '总价：'
  },
  getQueueButton: {
    id: 'Dapatkan Nomor Antrian',
    en: 'Get Queue Number',
    zh: '获取队列号码'
  },
  processing: {
    id: 'Memproses...',
    en: 'Processing...',
    zh: '处理中...'
  },
  people: {
    id: 'orang',
    en: 'people',
    zh: '人'
  },
  // New translations for country selection
  countryOrigin: {
    id: 'Negara Asal',
    en: 'Country of Origin',
    zh: '原籍国家'
  },
  selectCountry: {
    id: 'Pilih negara asal',
    en: 'Select country of origin',
    zh: '选择原籍国家'
  }
};
const LanguageContext = createContext<LanguageContextType | undefined>(undefined);
export const LanguageProvider: React.FC<{
  children: ReactNode;
}> = ({
  children
}) => {
  const [language, setLanguage] = useState<Language>('id');
  const value = {
    language,
    setLanguage,
    translations: defaultTranslations
  };
  return <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>;
};
export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};