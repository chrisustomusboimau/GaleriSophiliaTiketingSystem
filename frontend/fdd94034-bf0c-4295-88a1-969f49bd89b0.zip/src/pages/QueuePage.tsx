import React, { useEffect, useState } from 'react';
import { useParams, Navigate } from 'react-router-dom';
import { getVisitorByQueueNumber, Visitor } from '../utils/supabase';
import QueueDisplay from '../components/QueueDisplay';
const QueuePage: React.FC = () => {
  const {
    id
  } = useParams<{
    id: string;
  }>();
  const [visitor, setVisitor] = useState<Visitor | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    const loadVisitor = async () => {
      if (!id) return;
      try {
        setIsLoading(true);
        const visitorData = await getVisitorByQueueNumber(parseInt(id));
        setVisitor(visitorData);
      } catch (err) {
        console.error('Error loading visitor data:', err);
        setError('Gagal memuat data pengunjung');
      } finally {
        setIsLoading(false);
      }
    };
    loadVisitor();
  }, [id]);
  if (!id) {
    return <Navigate to="/" />;
  }
  return <div className="min-h-screen bg-slate-50 flex flex-col">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto py-4 px-4">
          <h1 className="text-2xl font-bold text-gray-800">Museum Ticketing</h1>
        </div>
      </header>
      <main className="flex-1 flex flex-col p-4">
        {isLoading ? <div className="flex items-center justify-center h-full">
            <p className="text-gray-600">Memuat data pengunjung...</p>
          </div> : error ? <div className="w-full max-w-md mx-auto bg-white rounded-lg shadow-md p-6">
            <div className="text-center text-red-600">
              <p>{error}</p>
              <button onClick={() => window.location.href = '/'} className="mt-4 text-blue-600 hover:text-blue-800">
                Kembali ke Halaman Utama
              </button>
            </div>
          </div> : visitor ? <QueueDisplay visitor={visitor} /> : <div className="w-full max-w-md mx-auto bg-white rounded-lg shadow-md p-6">
            <div className="text-center text-red-600">
              <p>Data pengunjung tidak ditemukan</p>
              <button onClick={() => window.location.href = '/'} className="mt-4 text-blue-600 hover:text-blue-800">
                Kembali ke Halaman Utama
              </button>
            </div>
          </div>}
      </main>
    </div>;
};
export default QueuePage;