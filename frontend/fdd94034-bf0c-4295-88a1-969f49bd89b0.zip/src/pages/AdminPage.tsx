import React from 'react';
import AdminDashboard from '../components/AdminDashboard';
const AdminPage: React.FC = () => {
  return <div className="min-h-screen bg-slate-50 flex flex-col">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto py-4 px-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-800">Museum Ticketing</h1>
          <div className="text-sm font-medium bg-blue-100 text-blue-800 px-3 py-1 rounded-full">
            Admin Panel
          </div>
        </div>
      </header>
      <main className="flex-1 p-4">
        <div className="max-w-7xl mx-auto">
          <AdminDashboard />
        </div>
      </main>
    </div>;
};
export default AdminPage;