import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import ScanPage from './pages/ScanPage';
import VisitorFormPage from './pages/VisitorFormPage';
import QueuePage from './pages/QueuePage';
import AdminPage from './pages/AdminPage';
import { LanguageProvider } from './contexts/LanguageContext';
export function App() {
  return <LanguageProvider>
      <BrowserRouter>
        <div className="w-full min-h-screen bg-slate-50">
          <Routes>
            <Route path="/" element={<ScanPage />} />
            <Route path="/form" element={<VisitorFormPage />} />
            <Route path="/queue/:id" element={<QueuePage />} />
            <Route path="/admin" element={<AdminPage />} />
          </Routes>
        </div>
      </BrowserRouter>
    </LanguageProvider>;
}