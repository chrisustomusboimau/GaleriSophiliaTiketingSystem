import { createClient } from '@supabase/supabase-js';
// In a production environment, these would be environment variables
const supabaseUrl = 'https://your-supabase-url.supabase.co';
const supabaseKey = 'your-supabase-key';
export const supabase = createClient(supabaseUrl, supabaseKey);
export interface Visitor {
  id: string;
  queue_number: number;
  timestamp: string;
  under_8_count: number;
  under_22_count: number;
  adult_count: number;
  total_price: number;
  status: 'pending' | 'paid';
  country_origin?: string;
}
export async function saveVisitorData(visitorData: Omit<Visitor, 'id' | 'timestamp'>) {
  const {
    data,
    error
  } = await supabase.from('visitors').insert([{
    ...visitorData,
    timestamp: new Date().toISOString()
  }]).select();
  if (error) throw error;
  return data?.[0];
}
export async function getVisitorByQueueNumber(queueNumber: number) {
  const {
    data,
    error
  } = await supabase.from('visitors').select('*').eq('queue_number', queueNumber).single();
  if (error) throw error;
  return data as Visitor;
}
export async function updatePaymentStatus(id: string, status: 'paid') {
  const {
    data,
    error
  } = await supabase.from('visitors').update({
    status
  }).eq('id', id).select();
  if (error) throw error;
  return data?.[0];
}
export async function getLatestQueueNumber() {
  const {
    data,
    error
  } = await supabase.from('visitors').select('queue_number').order('queue_number', {
    ascending: false
  }).limit(1);
  if (error) throw error;
  return data?.[0]?.queue_number || 0;
}
export async function getPendingVisitors() {
  const {
    data,
    error
  } = await supabase.from('visitors').select('*').eq('status', 'pending').order('timestamp', {
    ascending: true
  });
  if (error) throw error;
  return data as Visitor[];
}