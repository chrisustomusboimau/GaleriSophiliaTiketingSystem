export const PRICES = {
  UNDER_8: 25000,
  UNDER_22: 50000,
  ADULT: 100000
};
export function calculateTotalPrice(under8Count: number, under22Count: number, adultCount: number): number {
  return under8Count * PRICES.UNDER_8 + under22Count * PRICES.UNDER_22 + adultCount * PRICES.ADULT;
}
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
}