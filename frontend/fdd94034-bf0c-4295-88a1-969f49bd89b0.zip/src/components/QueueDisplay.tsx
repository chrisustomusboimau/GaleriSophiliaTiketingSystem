import React from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { Visitor } from '../utils/supabase';
import { formatCurrency } from '../utils/priceCalculator';
// Get country name from country code
const getCountryName = (countryCode?: string) => {
  if (!countryCode) return '';
  const countries = [{
    code: 'id',
    name: 'Indonesia'
  }, {
    code: 'us',
    name: 'United States'
  }, {
    code: 'gb',
    name: 'United Kingdom'
  }, {
    code: 'cn',
    name: 'China'
  }, {
    code: 'jp',
    name: 'Japan'
  }, {
    code: 'kr',
    name: 'South Korea'
  }, {
    code: 'sg',
    name: 'Singapore'
  }, {
    code: 'my',
    name: 'Malaysia'
  }, {
    code: 'au',
    name: 'Australia'
  }, {
    code: 'de',
    name: 'Germany'
  }, {
    code: 'fr',
    name: 'France'
  }, {
    code: 'nl',
    name: 'Netherlands'
  }, {
    code: 'it',
    name: 'Italy'
  }, {
    code: 'es',
    name: 'Spain'
  }, {
    code: 'ru',
    name: 'Russia'
  }, {
    code: 'in',
    name: 'India'
  }, {
    code: 'th',
    name: 'Thailand'
  }, {
    code: 'vn',
    name: 'Vietnam'
  }, {
    code: 'ph',
    name: 'Philippines'
  }, {
    code: 'ae',
    name: 'United Arab Emirates'
  }];
  const country = countries.find(c => c.code === countryCode);
  return country ? country.name : countryCode;
};
interface QueueDisplayProps {
  visitor: Visitor;
}
const QueueDisplay: React.FC<QueueDisplayProps> = ({
  visitor
}) => {
  return <div className="w-full max-w-md mx-auto bg-white rounded-lg shadow-md overflow-hidden">
      <div className="bg-blue-600 p-6 text-center">
        <h2 className="text-white text-xl font-bold mb-1">
          Nomor Antrian Anda
        </h2>
        <div className="text-5xl font-bold text-white">
          {visitor.queue_number}
        </div>
      </div>
      <div className="p-6">
        <div className="flex justify-center mb-6">
          <QRCodeSVG value={JSON.stringify({
          queueNumber: visitor.queue_number,
          id: visitor.id
        })} size={180} includeMargin={true} bgColor={'#ffffff'} fgColor={'#000000'} level={'L'} />
        </div>
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-3">
            Detail Pengunjung
          </h3>
          <div className="space-y-2 text-gray-700">
            {visitor.under_8_count > 0 && <div className="flex justify-between">
                <span>Anak (Di bawah 8 tahun):</span>
                <span className="font-medium">
                  {visitor.under_8_count} orang
                </span>
              </div>}
            {visitor.under_22_count > 0 && <div className="flex justify-between">
                <span>Remaja (Di bawah 22 tahun):</span>
                <span className="font-medium">
                  {visitor.under_22_count} orang
                </span>
              </div>}
            {visitor.adult_count > 0 && <div className="flex justify-between">
                <span>Dewasa (22 tahun ke atas):</span>
                <span className="font-medium">{visitor.adult_count} orang</span>
              </div>}
            {visitor.country_origin && <div className="flex justify-between">
                <span>Negara Asal:</span>
                <span className="font-medium">
                  {getCountryName(visitor.country_origin)}
                </span>
              </div>}
            <div className="flex justify-between pt-2 border-t border-gray-200 mt-2">
              <span className="font-medium">Total Harga:</span>
              <span className="font-bold text-blue-700">
                {formatCurrency(visitor.total_price)}
              </span>
            </div>
          </div>
        </div>
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <p className="text-sm text-yellow-800">
            Silakan tunjukkan nomor antrian ini kepada petugas kasir untuk
            melakukan pembayaran.
          </p>
        </div>
      </div>
    </div>;
};
export default QueueDisplay;