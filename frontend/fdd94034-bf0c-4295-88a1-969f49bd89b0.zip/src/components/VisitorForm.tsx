import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { calculateTotalPrice, formatCurrency, PRICES } from '../utils/priceCalculator';
import { saveVisitorData, getLatestQueueNumber } from '../utils/supabase';
import { useLanguage } from '../contexts/LanguageContext';
// Country list with language-based defaults
const COUNTRIES = [{
  code: 'id',
  name: 'Indonesia'
}, {
  code: 'us',
  name: 'United States'
}, {
  code: 'gb',
  name: 'United Kingdom'
}, {
  code: 'cn',
  name: 'China'
}, {
  code: 'jp',
  name: 'Japan'
}, {
  code: 'kr',
  name: 'South Korea'
}, {
  code: 'sg',
  name: 'Singapore'
}, {
  code: 'my',
  name: 'Malaysia'
}, {
  code: 'au',
  name: 'Australia'
}, {
  code: 'de',
  name: 'Germany'
}, {
  code: 'fr',
  name: 'France'
}, {
  code: 'nl',
  name: 'Netherlands'
}, {
  code: 'it',
  name: 'Italy'
}, {
  code: 'es',
  name: 'Spain'
}, {
  code: 'ru',
  name: 'Russia'
}, {
  code: 'in',
  name: 'India'
}, {
  code: 'th',
  name: 'Thailand'
}, {
  code: 'vn',
  name: 'Vietnam'
}, {
  code: 'ph',
  name: 'Philippines'
}, {
  code: 'ae',
  name: 'United Arab Emirates'
}].sort((a, b) => a.name.localeCompare(b.name));
const getDefaultCountryByLanguage = (language: string) => {
  switch (language) {
    case 'id':
      return 'id';
    // Indonesia
    case 'en':
      return 'us';
    // United States
    case 'zh':
      return 'cn';
    // China
    default:
      return 'id';
  }
};
const VisitorForm: React.FC = () => {
  const [under8Count, setUnder8Count] = useState(0);
  const [under22Count, setUnder22Count] = useState(0);
  const [adultCount, setAdultCount] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [countryCode, setCountryCode] = useState('');
  const navigate = useNavigate();
  const {
    language,
    translations
  } = useLanguage();
  // Set default country based on selected language
  useEffect(() => {
    setCountryCode(getDefaultCountryByLanguage(language));
  }, [language]);
  const totalPrice = calculateTotalPrice(under8Count, under22Count, adultCount);
  const totalVisitors = under8Count + under22Count + adultCount;
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (totalVisitors === 0) {
      alert('Mohon masukkan jumlah pengunjung');
      return;
    }
    try {
      setIsSubmitting(true);
      // Get the latest queue number and increment it
      const latestQueueNumber = await getLatestQueueNumber();
      const newQueueNumber = latestQueueNumber + 1;
      // Save visitor data
      const visitorData = await saveVisitorData({
        queue_number: newQueueNumber,
        under_8_count: under8Count,
        under_22_count: under22Count,
        adult_count: adultCount,
        total_price: totalPrice,
        status: 'pending',
        country_origin: countryCode
      });
      // Navigate to queue page
      navigate(`/queue/${visitorData.id}`);
    } catch (error) {
      console.error('Error submitting form:', error);
      alert('Terjadi kesalahan. Silakan coba lagi.');
    } finally {
      setIsSubmitting(false);
    }
  };
  const CounterInput = ({
    value,
    onChange,
    label,
    price
  }: {
    value: number;
    onChange: (value: number) => void;
    label: string;
    price: number;
  }) => {
    // Calculate subtotal for this ticket type
    const subtotal = value * price;
    // Handle manual input change
    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const newValue = parseInt(e.target.value) || 0;
      if (newValue >= 0) {
        onChange(newValue);
      }
    };
    return <div className="mb-6 border rounded-lg p-4 bg-white shadow-sm">
        <div className="flex justify-between items-center mb-2">
          <label className="text-lg font-medium text-gray-700">{label}</label>
          <span className="text-gray-600 font-medium">
            {formatCurrency(price)}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <button type="button" className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 font-bold text-xl flex items-center justify-center" onClick={() => onChange(Math.max(0, value - 1))} disabled={value === 0}>
            -
          </button>
          {/* Manual input field */}
          <div className="mx-2 flex-1 max-w-[100px]">
            <input type="number" min="0" value={value} onChange={handleInputChange} className="w-full text-center py-2 px-3 border border-gray-300 rounded-md text-xl font-bold text-gray-800 focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50" />
          </div>
          <button type="button" className="w-10 h-10 rounded-full bg-blue-600 text-white font-bold text-xl flex items-center justify-center" onClick={() => onChange(value + 1)}>
            +
          </button>
        </div>
        {/* Show subtotal when there are tickets of this type */}
        {value > 0 && <div className="mt-3 text-right">
            <div className="text-sm text-gray-600">
              {value} × {formatCurrency(price)} ={' '}
              <span className="font-medium text-blue-700">
                {formatCurrency(subtotal)}
              </span>
            </div>
          </div>}
      </div>;
  };
  return <form onSubmit={handleSubmit} className="w-full max-w-md mx-auto">
      <div className="mb-6">
        <h2 className="text-xl font-bold text-gray-800 mb-1">
          {translations.visitorCount[language]}
        </h2>
        <p className="text-gray-600">
          {translations.visitorDescription[language]}
        </p>
      </div>
      <CounterInput value={under8Count} onChange={setUnder8Count} label={translations.childLabel[language]} price={PRICES.UNDER_8} />
      <CounterInput value={under22Count} onChange={setUnder22Count} label={translations.teenLabel[language]} price={PRICES.UNDER_22} />
      <CounterInput value={adultCount} onChange={setAdultCount} label={translations.adultLabel[language]} price={PRICES.ADULT} />
      {/* Country of Origin Selector */}
      <div className="mb-6 border rounded-lg p-4 bg-white shadow-sm">
        <label className="block text-lg font-medium text-gray-700 mb-2">
          {translations.countryOrigin[language]}
        </label>
        <select value={countryCode} onChange={e => setCountryCode(e.target.value)} className="w-full p-2 border border-gray-300 rounded-md focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
          {COUNTRIES.map(country => <option key={country.code} value={country.code}>
              {country.name}
            </option>)}
        </select>
      </div>
      <div className="mt-8 bg-blue-50 p-4 rounded-lg">
        <div className="flex justify-between items-center mb-2">
          <span className="text-gray-700">
            {translations.totalVisitors[language]}
          </span>
          <span className="font-bold text-gray-800">
            {totalVisitors} {translations.people[language]}
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-gray-700">
            {translations.totalPrice[language]}
          </span>
          <span className="font-bold text-xl text-blue-700">
            {formatCurrency(totalPrice)}
          </span>
        </div>
      </div>
      <button type="submit" className="w-full mt-6 bg-blue-600 text-white py-3 px-4 rounded-lg font-medium text-lg hover:bg-blue-700 transition-colors" disabled={isSubmitting || totalVisitors === 0}>
        {isSubmitting ? translations.processing[language] : translations.getQueueButton[language]}
      </button>
    </form>;
};
export default VisitorForm;