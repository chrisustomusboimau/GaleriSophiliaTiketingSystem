import React, { useEffect, useState } from 'react';
import { Html5QrcodeScanner } from 'html5-qrcode';
interface BarcodeScannerProps {
  onScanSuccess: (decodedText: string) => void;
  onScanFailure?: (error: any) => void;
}
const BarcodeScanner: React.FC<BarcodeScannerProps> = ({
  onScanSuccess,
  onScanFailure
}) => {
  const [isScanning, setIsScanning] = useState(false);
  useEffect(() => {
    // Create scanner instance
    const scanner = new Html5QrcodeScanner('reader', {
      fps: 10,
      qrbox: {
        width: 250,
        height: 250
      }
    }, /* verbose= */false);
    const success = (decodedText: string) => {
      setIsScanning(true);
      scanner.clear();
      onScanSuccess(decodedText);
    };
    const error = (err: any) => {
      if (onScanFailure) {
        onScanFailure(err);
      }
    };
    if (!isScanning) {
      scanner.render(success, error);
    }
    // Cleanup
    return () => {
      if (!isScanning) {
        scanner.clear();
      }
    };
  }, [onScanSuccess, onScanFailure, isScanning]);
  return <div className="w-full max-w-md mx-auto">
      <div id="reader" className="w-full"></div>
    </div>;
};
export default BarcodeScanner;