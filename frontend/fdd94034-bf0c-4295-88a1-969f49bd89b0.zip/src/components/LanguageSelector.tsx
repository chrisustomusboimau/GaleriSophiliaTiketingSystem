import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
const LanguageSelector: React.FC = () => {
  const {
    language,
    setLanguage,
    translations
  } = useLanguage();
  const navigate = useNavigate();
  const handleContinue = () => {
    navigate('/form');
  };
  return <div className="w-full max-w-md bg-white rounded-lg shadow-md p-6">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">
          {translations.welcomeTitle[language]}
        </h2>
        <p className="text-gray-600">
          {translations.welcomeDescription[language]}
        </p>
      </div>
      <div className="grid grid-cols-3 gap-4 mb-8">
        <button onClick={() => setLanguage('id')} className={`flex flex-col items-center justify-center p-4 rounded-lg border-2 transition-all ${language === 'id' ? 'border-blue-600 bg-blue-50' : 'border-gray-200 hover:border-blue-300'}`}>
          <div className="w-12 h-12 flex items-center justify-center bg-red-100 rounded-full mb-2">
            <span className="text-xl font-bold text-red-600">ID</span>
          </div>
          <span className="font-medium text-gray-800">Indonesia</span>
        </button>
        <button onClick={() => setLanguage('en')} className={`flex flex-col items-center justify-center p-4 rounded-lg border-2 transition-all ${language === 'en' ? 'border-blue-600 bg-blue-50' : 'border-gray-200 hover:border-blue-300'}`}>
          <div className="w-12 h-12 flex items-center justify-center bg-blue-100 rounded-full mb-2">
            <span className="text-xl font-bold text-blue-600">EN</span>
          </div>
          <span className="font-medium text-gray-800">English</span>
        </button>
        <button onClick={() => setLanguage('zh')} className={`flex flex-col items-center justify-center p-4 rounded-lg border-2 transition-all ${language === 'zh' ? 'border-blue-600 bg-blue-50' : 'border-gray-200 hover:border-blue-300'}`}>
          <div className="w-12 h-12 flex items-center justify-center bg-yellow-100 rounded-full mb-2">
            <span className="text-xl font-bold text-yellow-600">中</span>
          </div>
          <span className="font-medium text-gray-800">中文</span>
        </button>
      </div>
      <button onClick={handleContinue} className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-medium text-lg hover:bg-blue-700 transition-colors">
        {translations.continueButton[language]}
      </button>
    </div>;
};
export default LanguageSelector;