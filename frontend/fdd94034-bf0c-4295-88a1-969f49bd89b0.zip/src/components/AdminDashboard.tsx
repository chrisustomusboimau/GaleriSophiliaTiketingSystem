import React, { useEffect, useState } from 'react';
import { Visitor, getPendingVisitors, updatePaymentStatus } from '../utils/supabase';
import { formatCurrency } from '../utils/priceCalculator';
const AdminDashboard: React.FC = () => {
  const [visitors, setVisitors] = useState<Visitor[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [processingId, setProcessingId] = useState<string | null>(null);
  const loadVisitors = async () => {
    try {
      setIsLoading(true);
      const pendingVisitors = await getPendingVisitors();
      setVisitors(pendingVisitors);
    } catch (error) {
      console.error('Error loading visitors:', error);
      alert('Gagal memuat data pengunjung');
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    loadVisitors();
    // Set up polling to refresh data every 30 seconds
    const interval = setInterval(loadVisitors, 30000);
    return () => clearInterval(interval);
  }, []);
  const handlePaymentConfirmation = async (id: string) => {
    try {
      setProcessingId(id);
      await updatePaymentStatus(id, 'paid');
      // Update local state
      setVisitors(visitors.filter(visitor => visitor.id !== id));
    } catch (error) {
      console.error('Error confirming payment:', error);
      alert('Gagal memperbarui status pembayaran');
    } finally {
      setProcessingId(null);
    }
  };
  return <div className="w-full">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Dashboard Kasir</h2>
        <p className="text-gray-600">Kelola pembayaran tiket pengunjung</p>
      </div>
      <div className="mb-4 flex justify-between items-center">
        <div>
          <h3 className="font-medium text-gray-700">
            Pengunjung Menunggu:{' '}
            <span className="font-bold text-blue-700">{visitors.length}</span>
          </h3>
        </div>
        <button onClick={loadVisitors} className="text-blue-600 hover:text-blue-800 flex items-center" disabled={isLoading}>
          {isLoading ? 'Memuat...' : 'Segarkan'}
        </button>
      </div>
      {visitors.length === 0 ? <div className="bg-gray-50 rounded-lg p-8 text-center">
          <p className="text-gray-600">
            {isLoading ? 'Memuat data pengunjung...' : 'Tidak ada pengunjung yang menunggu pembayaran'}
          </p>
        </div> : <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {visitors.map(visitor => <div key={visitor.id} className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
              <div className="bg-blue-600 p-4 text-white">
                <div className="flex justify-between items-center">
                  <h4 className="font-bold text-lg">
                    Nomor Antrian: {visitor.queue_number}
                  </h4>
                  <span className="text-xs bg-blue-500 px-2 py-1 rounded">
                    {new Date(visitor.timestamp).toLocaleTimeString()}
                  </span>
                </div>
              </div>
              <div className="p-4">
                <div className="space-y-2 text-sm">
                  {visitor.under_8_count > 0 && <div className="flex justify-between">
                      <span>Anak (Di bawah 8 tahun):</span>
                      <span>
                        {visitor.under_8_count} × Rp 25.000 ={' '}
                        {formatCurrency(visitor.under_8_count * 25000)}
                      </span>
                    </div>}
                  {visitor.under_22_count > 0 && <div className="flex justify-between">
                      <span>Remaja (Di bawah 22 tahun):</span>
                      <span>
                        {visitor.under_22_count} × Rp 50.000 ={' '}
                        {formatCurrency(visitor.under_22_count * 50000)}
                      </span>
                    </div>}
                  {visitor.adult_count > 0 && <div className="flex justify-between">
                      <span>Dewasa (22 tahun ke atas):</span>
                      <span>
                        {visitor.adult_count} × Rp 100.000 ={' '}
                        {formatCurrency(visitor.adult_count * 100000)}
                      </span>
                    </div>}
                  <div className="flex justify-between pt-2 border-t border-gray-200 mt-2 font-medium">
                    <span>Total:</span>
                    <span className="text-blue-700">
                      {formatCurrency(visitor.total_price)}
                    </span>
                  </div>
                </div>
                <button onClick={() => handlePaymentConfirmation(visitor.id)} className="w-full mt-4 bg-green-600 text-white py-2 px-4 rounded font-medium hover:bg-green-700 transition-colors" disabled={processingId === visitor.id}>
                  {processingId === visitor.id ? 'Memproses...' : 'Konfirmasi Pembayaran'}
                </button>
              </div>
            </div>)}
        </div>}
    </div>;
};
export default AdminDashboard;